
class Solution:
    def climbStairs(self, n: int) -> int:
        q = 0
        r = 1
        for i in range(n):
            p = q
            q = r
            r = p + q
        return r
s = Solution()
print(s.climbStairs(3))







class Solution1:
    def climbStairs(self, n: int) -> int:
        y = 0
        z = 1
        for i in range(n):
            x = y
            y = z
            z = x + y
        return z












