

class BSTIterator:

    def __init__(self, root):

        pass
    def next(self) -> int:

        pass
    def hasNext(self) -> bool:

        pass