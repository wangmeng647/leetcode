
class Solution:
    def strStr(self, haystack: str, needle: str) -> int:
        def create_next(p):
            next_table = [-1]
            n = len(p)
            t = -1
            for i in range(1, n):
                while True:
                    if t < 0 or p[i - 1] == p[t]:
                        t += 1
                        if p[i] == p[t]:
                            next_table.append(next_table[t])
                        else:
                            next_table.append(t)
                        break
                    else:
                        t = next_table[t]
            return next_table

        def match(s, p):
            nx_table = create_next(p)
            i = j = 0
            while i < len(s) and j < len(p):
                if j < 0 or s[i] == p[j]:
                    i += 1
                    j += 1
                    if j == len(p):
                        return i - len(p)
                else:
                    j = nx_table[j]
            return -1
        return match(haystack, needle)

s = Solution()
haystack = "sasdbutsad"
needle = "sad"
print(s.strStr(haystack, needle))