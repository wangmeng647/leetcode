import collections

class Solution:
    aim = False
    cache = set()
    def calcEquation(self, equations, values, queries):
        dic = collections.defaultdict(list)
        ans =[]
        def dfs(node, end_node):
            if node not in dic or node in self.cache:
                return
            self.cache.add(node)
            if node == end_node:
                self.aim = True
                return 1
            for i in range(0, len(dic[node]), 2):
                nx = dfs(dic[node][i], end_node)
                if self.aim == True:
                    return dic[node][i + 1] * nx

        for equal, val in zip(equations, values):
            dic[equal[0]].append(equal[1])
            dic[equal[0]].append(val)
            dic[equal[1]].append(equal[0])
            dic[equal[1]].append(1 / val)
        for q in queries:
            if q[0] not in dic or q[1] not in dic:
                ans.append(-1)
            else:
                self.cache.clear()
                self.aim = False
                mul = dfs(q[0], q[1])
                if mul == None:
                    ans.append(-1)
                else:
                    ans.append(mul)
        return ans


#2
class Solution2:
    aim = False
    cache = set()
    def calcEquation(self, equations, values, queries):
        path = collections.defaultdict()
        path_weight = collections.defaultdict()
        def search_update(node):
            if node not in path:
                return 1, node
            node_father = path[node]
            pre_weight, root = search_update(node_father)
            path[node] = root
            weight_self = path_weight[node]
            path_weight[node] = weight_self * pre_weight
            return weight_self * pre_weight, root

        for i in range(len(equations)):
            begin, end, weight = equations[i][0], equations[i][1], values[i]
            begin_weight, root_b = search_update(begin)
            end_weight, root_e = search_update(end)
            if root_b == root_e:
                continue
            path[begin] = root_e
            path_weight[begin] = weight * end_weight
            path_weight[root_e] = 1
            if begin in path:
                path[root_b] = root_e
                path_weight[root_b] = weight * end_weight / begin_weight
        ans = []
        for start, end in queries:
            begin_weight, root_s = search_update(start)
            end_weight, root_e = search_update(end)
            if root_s not in path_weight or root_e not in path_weight or root_s != root_e:
                ans.append(-1)
            else:
                ans.append(begin_weight / end_weight)
        return ans

s = Solution2()
equations = [["a","b"],["b","c"],["a","c"]]
values = [2.0,3.0,6.0]
queries = [["a","c"],["b","a"],["a","e"],["a","a"],["x","x"]]
#result [1.33333,1.0,-1.0]
print(s.calcEquation(equations, values, queries))
print(2)