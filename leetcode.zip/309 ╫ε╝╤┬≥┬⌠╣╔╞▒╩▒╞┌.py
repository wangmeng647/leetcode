
class Solution:
    def maxProfit(self, prices) -> int:
        f_0 = -prices[0]
        f_1 = 0
        f_2 = 0
        for i in prices[1:]:
            r = f_0
            f_0 = max(f_0, f_1 - i)
            f_1 = max(f_1, f_2)
            f_2 = r + i
        return max(f_0, f_1, f_2)

prices = [1,2,3,0,2]
s = Solution()
print(s.maxProfit(prices))