import collections
import functools

#超时dfs
class Solution:
    def canPartition(self, nums) -> bool:
        total = sum(nums)
        if total % 2 == 1:
            return False
        remainder = int(total / 2)
        def dfs(remainder, nums):
            if remainder == 0:
                return True
            if remainder < 0:
                return False
            r = False
            for i in range(len(nums)):
                r_i = dfs(remainder - nums[i], nums[0:i] + nums[i + 1:len(nums)])
                r = r or r_i
            return r
        return dfs(remainder, nums)

class Solution2:
    def canPartition(self, nums) -> bool:
        total = sum(nums)
        if total % 2 == 1:
            return False
        target = int(total / 2)
        n = target + 1
        dp = [False] * n
        dp[0] = True
        for number in nums:
            if dp[-1] is True:
                return True
            for j in reversed(range(n)):
                if j - number >= 0:
                    dp[j] = dp[j - number] or dp[j]
        return dp[-1]




#2
class Solution3:
    def canPartition(self, nums) -> bool:
        total = sum(nums)
        if total % 2 == 1:
            return False
        aim = total // 2
        dp = [False] * (aim + 1)
        for i in range(len(nums)):
            dp[0] = True
        for i in range(len(nums)):
            for j in reversed(range(1, aim + 1)):
                if j - nums[i] >= 0:
                    dp[j] = dp[j] or dp[j - nums[i]]
        return dp[-1]

s = Solution3()
nums = [1,5,10,6]
print(s.canPartition(nums))