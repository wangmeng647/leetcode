import copy
class Solution:
    def combinationSum(self, candidates, target: int):
        ans = []
        combination = []
        n = len(candidates)
        def dfs(combination, index, target_remain):
            if index == n:
                return
            if target_remain - candidates[index] == 0:
                combination.append(candidates[index])
                ans.append(copy.copy(combination))
                combination.pop()
            dfs(combination, index + 1, target_remain)
            if target_remain - candidates[index] < 0:
                return
            combination.append(candidates[index])
            dfs(combination, index, target_remain - candidates[index])
            combination.pop()
        dfs(combination, 0, target)
        return ans



#2
class Solution2:
    def combinationSum(self, candidates, target: int):
        n = len(candidates)
        ans = []
        combination = []
        def dfs(index, target):
            if target == 0:
                ans.append(copy.deepcopy(combination))
                return
            if index == n:
                return
            if target - candidates[index] >= 0:
                dfs(index + 1, target)
                combination.append(candidates[index])
                dfs(index, target - candidates[index])
                combination.pop()
            else:
                dfs(index + 1, target)
        dfs(0, target)
        return ans
s = Solution2()
candidates = [4,2,8]
target = 8
print(s.combinationSum(candidates, target))