import functools


class Solution:
    def generateParenthesis(self, n: int):
        lis = []
        def dfs(parenthese, left, right):
            if left > n or right > left:
                return
            if left == n and right == n:
                lis.append(parenthese)
            dfs(parenthese + '(', left + 1, right)
            dfs(parenthese + ')', left, right + 1)
        dfs('', 0, 0)
        return lis




#2
class Solution1:
    def generateParenthesis(self, n: int):
        lis = []
        bracket = []
        def dfs(l, r):
            if l > n or r > l:
                return
            if l == r == n:
                lis.append(''.join(bracket))
                return
            bracket.append('(')
            dfs(l + 1, r)
            bracket.pop()
            bracket.append(')')
            dfs(l, r + 1)
            bracket.pop()
        dfs(0, 0)
        return lis


class Solution2:
    def generateParenthesis(self, n: int):
        @functools.lru_cache(maxsize=None)
        def dfs(k):
            if k == 0:
                return ['']
            ans = []
            for i in range(k):
                a = dfs(i)
                b = dfs(k - i - 1)
                for l in a:
                    for r in b:
                        ans.append('(' + l + ')' + r)
            return ans
        return dfs(n)
s = Solution2()
a = s.generateParenthesis(5)
print(a)
print(len(a))