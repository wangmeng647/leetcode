

class Solution:
    def maxProfit(self, prices) -> int:

        f_hold = -prices[0]
        f_sale = 0
        for p in prices[1:]:
            f_hold = max(f_hold, f_sale - p)
            f_sale = max(f_hold + p, f_sale)
        return f_sale

prices = [7,1,5,3,6,4]
s = Solution()
print(s.maxProfit(prices))



#2
class Solution2:
    def maxProfit(self, prices) -> int:
        hold = -prices[0]
        un_hold = 0
        for p in prices:
            hold_cache = hold
            hold = max(un_hold - p, hold)
            un_hold = max(hold_cache + p, un_hold)
        return un_hold