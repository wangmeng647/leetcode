
class Solution:
    def maxProfit(self, prices) -> int:
        buy_1 = -prices[0]
        sell_1 = 0
        buy_2 = -prices[0]
        sell_2 = 0
        for p in prices[1:]:
            buy_1 = max(buy_1, -p)
            sell_1 = max(buy_1 + p, sell_1)
            buy_2 = max(sell_1 - p, buy_2)
            sell_2 = max(buy_2 + p, sell_2)
        return max(sell_1, sell_2)

s= Solution()
prices = [1,2,3,4,5]
print(s.maxProfit(prices))
