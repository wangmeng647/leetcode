
class Solution:
    def maxProfit(self, k: int, prices):
        n = len(prices)
        if k > n // 2:
            k = n // 2
        dp = 2 * k * [0] + [0]
        for i in range(1, len(dp), 2):
            dp[i] = -prices[0]
        for p in prices:
            for j in range(1, len(dp)):
                if j % 2 == 1:
                    dp[j] = max(dp[j], dp[j - 1] - p)
                else:
                    dp[j] = max(dp[j], dp[j - 1] + p)
        return max(dp)
s = Solution()
k = 3
prices = [3,2,6,5,0,3]
print(s.maxProfit(k, prices))
